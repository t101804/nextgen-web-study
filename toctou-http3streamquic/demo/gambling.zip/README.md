# Gambling

## Description

Sports Gambling is evil and here's why

## Flag

`UMDCTF{d_D_d_dehH_@W_dANG_!7}`
